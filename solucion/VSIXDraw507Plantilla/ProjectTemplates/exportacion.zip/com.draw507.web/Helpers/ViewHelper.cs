﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Helpers
{
    public class ViewHelper
    {
        public static string IsActive(string actionName, string ControllerName)
        {
            return "";
        }
    }
}